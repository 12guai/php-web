<?php include('system/inc.php');
error_reporting(0);?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?php echo $mkcms_seoname;?>App下载</title> 
<link rel='stylesheet' href='css/down.css'/>
<meta property="og:title" content=""/>
<meta property="og:type" content="website"/>
<meta property="og:image:type" content="image/png">
<meta property="og:image:width" content="600">
<meta property="og:image:height" content="700">
</head>
<body>
<div class="bg-box">
	<div class="bg-img" style="background-image:url(https://ae01.alicdn.com/kf/Hca8dee921baa43d785ba5d2d3ee6db64T.gif)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUDOS.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUBy8.jpg)"></div>
	<div class="bg-img" style="background-image:url(https://ae01.alicdn.com/kf/H534f338c77e04616ad917e0096854e83o.gif)"></div>
	<div class="bg-img" style="background-image:url(https://ae01.alicdn.com/kf/Ha0687e68301c4cc1825d593c2bbe880fv.gif)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzU6oj.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUseg.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzU2Yn.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUgFs.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzURWq.jpg)"></div>
	<div class="bg-img" style="background-image:url(https://puui.qpic.cn/fans_admin/0/3_1192510060_1571556069998/0)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzU4yT.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUfS0.jpg)"></div>
	<div class="bg-img" style="background-image:url(/images/app/ZzUhlV.jpg)"></div>
	<div class="bg-img" style="background-image:url(https://ae01.alicdn.com/kf/H08eb54e2105c488198afe857ccb1f65dl.gif)"></div>
</div>
<div class="main-box">
	<div class="title">
      影视APP下载<br><span class="sub-title">最新电影、热播电视剧<b>牛</b><br>全网视频，免费在线观看<b>爽</b></span>
	</div>
	<a class="btn btn-ios" href="<?php echo $mkcms_appewm;?>" target="_blank"><img src="/images/app/apple.png" class="btn-icon">IOS下載</a>
	<a class="btn download-android" href="<?php echo $mkcms_appurl;?>" target="_blank"><img src="/images/app/android.png" class="btn-icon">安卓下載</a>
	<img src="/images/app/ZzscRJ.png" class="desc">
</div>
<div class="pop_sharebox" style="display: none;">
	<div class="img"><img src="/images/app/Zzs6G4.png"></div>
</div>
</body></html>