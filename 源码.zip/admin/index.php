<?php
	header('location:cms_login.php');
?>