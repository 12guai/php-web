<?php  include 'head.php';$dy='active'?>
<title>抖音在线解析 - <?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="抖音,抖音视频,抖音视频解析,抖音去水印">
<meta name="description" content="抖音去水印解析，<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
	<div class="row"><?php echo $mkcms_ad17; ?>
		<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel_hd">
				<div class="stui-pannel__head active bottom-line clearfix">
				<span class="more text-muted pull-right hidden-xs">抖音去水印解析</span>
					<ul class="nav nav-tabs">
					<li class="active"><a href="#">抖音视频</a></li>
					</ul>
				</div>
			</div>
			<div class="stui-pannel_bd">
				<ul class="stui-vodlist clearfix">
				<iframe src="/dy" width="100%" height="560" scrolling="no" frameborder="0"></iframe>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php  include 'footer.php';?>