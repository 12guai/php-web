<div class="stui-foot clearfix">
	<div class="container">
		<div class="row">
			<div class="col-pd text-center masked">
			<p><?php echo $mkcms_copyright;?></p>
			<p class="text-center"><?php echo $mkcms_tongji;?></p>
			</div>
		</div>
	</div>
</div>
</div>
<div id="footer" class="border-t hidden-lg hidden-md" >
	<ul class="flex-wrap" style="font-weight:bold">
		<a class="flex-con paiban <?php echo $index;?>" href="/index.html"><li onclick="randomSwitchBtn(this);">首页</li></a>
		<a class="flex-con paiban <?php echo $cx;?>" href="/cx.html"><li onclick="randomSwitchBtn(this);">抢先</li></a>
		<a class="flex-con paiban <?php echo $dt;?>" href="/hall.html"><li onclick="randomSwitchBtn(this);">大厅</li></a>
		<a class="flex-con paiban <?php echo $fl;?>" href="/fuli.html"><li onclick="randomSwitchBtn(this);">福利</li></a>
		<a class="flex-con paiban <?php echo $hy;?>" href="/ucenter"><li onclick="randomSwitchBtn(this);">我的</li></a>
	</ul>
</div>
	<ul class="stui-extra clearfix">
		<li class="hidden-xs"><a class="backtop" href="javascript:scroll(0,0)" style="display: block;"><i class="icon iconfont icon-less"></i></a></li>
		<li class="visible-xs"><a class="open-share" href="javascript:;"><i class="icon iconfont icon-share"></i></a></li>
		<li class="hidden-xs"><span><i class="icon iconfont icon-qrcode"></i></span>
		<div class="sideslip">
			<div class="col-pd  text-center">
			<img width="150" height="150" class="qrcode">
			<p class="text-center font-12">扫码用手机访问</p>
			</div>
		</div>
		</li>
		<li title="会员中心"><a class="open-share" href="/ucenter"><i class="icon iconfont icon-smile"></i></a></li>
		<li><a href="/book.html"><i class="icon iconfont icon-comments"></i></a></li>
	</ul>
</div>
</body>
</html>