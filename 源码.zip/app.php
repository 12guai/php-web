<?php include('system/inc.php');
error_reporting(0);
include('template/'.$mkcms_bdyun.'/app.php');?>