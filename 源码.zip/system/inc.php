<?php
require_once('conn.php');
require_once('library.php');
require_once('function.php');
require_once('config.php');
require_once('safe.php');
?>