<?php
//Mysql数据库信息
if(!defined('PCFINAL')) exit('Request Error!');
define('DATA_HOST', 'localhost');
define('DATA_USERNAME', 'movie');
define('DATA_PASSWORD', '123456');
define('DATA_NAME', 'movie');
?>